<html>
<head>
    <meta charset="UTF-8">    
    <title>Student Information Registration System</title>
</head>

<body style="background-color:#fff8e8; text-align: center;">
<img src="logo_utm.png" alt="This is UTM Logo"  width="300" height="100" >
    <h2 style="background-color:#FFEAC5;">Student Registration Form</h2>
    <form action="register.php" method="POST">
        <label for="name">Student Name: </label>
        <input type="text" name="name" required><br><br>
        <label for="email">Email: </label>
        <input type="email" name="email" required><br><br>
        <label for="course">Course: </label>
        <input type="text" name="course" required><br><br>
        <label for="year">Year of Study: </label>
        <select name="yr" required>
            <option value="">Select Year</option>
            <option value="1">Year 1</option>
            <option value="2">Year 2</option>
            <option value="3">Year 3</option>
            <option value="4">Year 4</option>
        </select><br><br>
        <button type="submit">Register</button>
    </form>

    <a href="view.php">View Student List</a>
</body>
</html>

<?php

include "db.php"; //Using database connection file here

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $course = $_POST['course'];
    $year = $_POST['yr'];

    $sql = "INSERT INTO students (name, email, course, yr) VALUES ('$name', '$email', '$course', '$year')";
    if(mysqli_query($conn,$sql)){
        echo "New record created successfully";
    } else {
        echo "Error: ". $sql. "<br>". mysqli_error($conn); 
    }
}
?>