<html>
    <head>
        <title>Registered Student List</title>
    </head>

<body style="background-color:#fff8e8; text-align: center;">
    <img src="logo_utm.png" alt="This is UTM Logo"  width="300" height="100" >
    <h2 style="background-color:#FFEAC5;">Student List</h2>
    <table border="1" style="width:80%; margin: 0 auto;">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Course</th>
            <th>Year of Study</th>
        </tr>
<?php
include 'db.php';

$sql = "SELECT * FROM students";
$result = mysqli_query($conn, "SELECT * FROM students");

if(mysqli_num_rows($result) > 0){
    while($row = mysqli_fetch_assoc($result)){
        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['email']."</td>";
        echo "<td>".$row['course']."</td>";
        echo "<td>".$row['yr']."</td>";
        echo "<td><a href='update.php?id=".$row['id']."'>Edit</a></td>";
        echo "<td><a href='delete.php?id=".$row['id']."'>Delete</a></td>";
        echo "</tr>";
    }
}else {
    echo "<tr><td colspan='5'> No Data Found </td></tr>";
}

?>
</table>

<a href="register.php">Register New Student</a>

</body>
</html>
