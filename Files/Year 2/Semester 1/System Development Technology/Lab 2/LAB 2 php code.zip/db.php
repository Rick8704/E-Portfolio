<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "lab_db";

//create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection

if (!$conn) {
    die("Connection failed: ". mysqli_connect_error());
}else{
    echo "Connected successfully<br>";
}

// Create table

?>