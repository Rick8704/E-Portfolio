<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Student</title>
</head>

<body style="background-color:#fff8e8; text-align: center;">
    <img src="logo_utm.png" alt="This is UTM Logo"  width="300" height="100" >
    <h2 style="background-color:#FFEAC5;">Update Student Details Form</h2>

    <?php

    include 'db.php';

    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "SELECT * FROM students WHERE id = $id";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
    
    // Prepare statement for the SELECT query
    $stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id); // 'i' indicates the type is integer
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Fetch data if exists
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Student not found.";
        exit; // Exit if no record is found
    }

    mysqli_stmt_close($stmt); // Close the statement

    }
    ?>

<form action="update.php?id=<?php echo $row["id"];?>" method="POST">
        <label >Student Name: </label>
        <input type="text" name="name" value="<?php echo $row['name'];?>"required><br><br>
        <label >Email: </label>
        <input type="email" name="email" value="<?php echo $row['email'];?>"required><br><br>
        <label >Course: </label>
        <input type="text" name="course" value="<?php echo $row['course'];?>"required><br><br>
        <label >Year of Study: </label>
        <select name="yr" required>
            <option value="">Select Year</option>
            <option value="1" <?php if($row['yr']==1) echo 'selected'; ?>>Year 1</option>
            <option value="2" <?php if($row['yr']==2) echo 'selected'; ?>>Year 2</option>
            <option value="3" <?php if($row['yr']==3) echo 'selected'; ?>>Year 3</option>
            <option value="4" <?php if($row['yr']==4) echo 'selected'; ?>>Year 4</option>
        </select><br><br>
        <button type="submit">Update</button>
    </form>

<?php
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $course = $_POST['course'];
        $year = $_POST['yr'];
        

        $sql = "UPDATE students SET name='$name', email='$email', course='$course', yr='$year' WHERE id=$id";
        // Prepare statement for the UPDATE query
        $stmt = mysqli_prepare($conn, "UPDATE students SET name = ?, email = ?, course = ?, yr = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'ssiii', $name, $email, $course, $year, $id); // Ensure $course is a string

        if (mysqli_query($conn, $sql)) {
            echo "Record successfully updated";
        } else {
            echo "Error: ". mysqli_error($conn);
        }
        mysqli_stmt_close($stmt); // Close the statement
    }
?>
<br>
<a href="view.php">Back to Student List</a>

</body>
</html>